#include <iostream>
#include "Gato.h"
using namespace std;
//Constructor de Gato
Gato::Gato(int edadInicial){
suEdad = edadInicial;
cout << "se creo   un objeto gato de edad de " << edadInicial << endl;
}
Gato::~Gato(){
cout << "el  objeto gato se destruira en 3, 2, 1, 0 adios ...." << endl;
}
// ObtenerEdad, metodo de acceso publico
// regresa el valor de su miembro suEdad
int Gato::ObtenerEdad(){
return suEdad;
}
// Definicion de AsignarEdad, metodo de
// acceso publico
void Gato::AsignarEdad(int edad){
// asignar a la variable miembro su Edad el
// valor pasado por el parametro edad
suEdad = edad;
}
// definicion del metodo Maullar
// regresa: void
// parametros: ninguno
// accion: imprime "miauu"
void Gato::Maullar(){
cout << "Miau" << endl;
}
