#include <iostream>
#include "Gato.h"

using namespace std;

int main(){

Gato black(4);
black.Maullar();

cout << "black es un gato que tiene";
cout << black.ObtenerEdad() << "anios " << endl;
black.Maullar();
black.AsignarEdad(6);
cout << "Ahora black tiene " ;
cout << black.ObtenerEdad() << " anios " << endl;
return 0;
}
